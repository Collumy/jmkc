package me.collumy.justtest

import justmc.annotation.*
import justmc.collection.*
import justmc.entity.*
import justmc.event.*
import justmc.flow.*
import justmc.player.*
import justmc.value.*

@EventHandler
fun onJoin(event: PlayerJoinEvent) {
}
